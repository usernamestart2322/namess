// Form Options
export const requestTypeOptions = [
  { value: 'communal', label: 'Жилищно-коммунальное хозяйство' },
  { value: 'construction', label: 'Строительство и архитектура' },
  { value: 'transport', label: 'Транспорт и дороги' },
  { value: 'ecology', label: 'Экология и благоустройство' },
  { value: 'social', label: 'Социальные вопросы' },
  { value: 'other', label: 'Другое' },
];

// Contact Information
export const contactInfo = {
  phone: '8 (800) 123-45-67',
  fax: '8 (800) 123-45-68',
  email: 'info@admincity.ru',
  hotline: '8 (800) 123-45-67',
};

// Working Hours
export const workingHours = {
  weekdays: 'Пн-Пт: 9:00 - 18:00',
  weekend: 'Сб-Вс: выходной',
  lunch: 'Обед: 13:00 - 14:00',
};