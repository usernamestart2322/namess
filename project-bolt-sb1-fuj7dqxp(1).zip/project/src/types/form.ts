import { ChangeEvent } from 'react';
import { LucideIcon } from 'lucide-react';

interface BaseFormProps {
  label: string;
  name: string;
  value: string;
  icon: LucideIcon;
  required?: boolean;
  error?: string;
}

export interface FormInputProps extends BaseFormProps {
  type: string;
  placeholder: string;
  onChange: (e: ChangeEvent<HTMLInputElement>) => void;
}

export interface FormSelectProps extends BaseFormProps {
  onChange: (e: ChangeEvent<HTMLSelectElement>) => void;
  options: { value: string; label: string; }[];
}

export interface FormTextareaProps extends BaseFormProps {
  placeholder: string;
  onChange: (e: ChangeEvent<HTMLTextAreaElement>) => void;
  rows?: number;
}

export interface RequestFormData {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  requestType: string;
  description: string;
}