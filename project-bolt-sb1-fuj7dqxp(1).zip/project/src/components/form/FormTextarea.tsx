import React from 'react';
import { FormTextareaProps } from '../../types/form';

const FormTextarea: React.FC<FormTextareaProps> = ({
  label,
  name,
  placeholder,
  value,
  onChange,
  icon: Icon,
  required = true,
  rows = 5,
  error
}) => {
  return (
    <div>
      <label className="flex items-center gap-2 text-gray-700 font-medium mb-2">
        <Icon size={18} className="text-blue-900" />
        {label}
      </label>
      <textarea
        name={name}
        required={required}
        rows={rows}
        className={`w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-900 focus:border-blue-900 transition-colors ${
          error ? 'border-red-500' : 'border-gray-300'
        }`}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
};

export default FormTextarea;