import React from 'react';
import { FormInputProps } from '../../types/form';

const FormInput: React.FC<FormInputProps> = ({ 
  label, 
  name, 
  type, 
  placeholder, 
  value, 
  onChange, 
  icon: Icon,
  required = true,
  error
}) => {
  return (
    <div>
      <label className="flex items-center gap-2 text-gray-700 font-medium mb-2">
        <Icon size={18} className="text-blue-900" />
        {label}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className={`w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-900 focus:border-blue-900 transition-colors ${
          error ? 'border-red-500' : 'border-gray-300'
        }`}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
};

export default FormInput;