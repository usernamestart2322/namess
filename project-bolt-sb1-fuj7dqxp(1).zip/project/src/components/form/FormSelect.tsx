import React from 'react';
import { FormSelectProps } from '../../types/form';

const FormSelect: React.FC<FormSelectProps> = ({
  label,
  name,
  value,
  onChange,
  icon: Icon,
  options,
  required = true,
  error
}) => {
  return (
    <div>
      <label className="flex items-center gap-2 text-gray-700 font-medium mb-2">
        <Icon size={18} className="text-blue-900" />
        {label}
      </label>
      <select
        name={name}
        required={required}
        className={`w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-900 focus:border-blue-900 transition-colors ${
          error ? 'border-red-500' : 'border-gray-300'
        }`}
        value={value}
        onChange={onChange}
      >
        <option value="">Выберите тип обращения</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
};

export default FormSelect;