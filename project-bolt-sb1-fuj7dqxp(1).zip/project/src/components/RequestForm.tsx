import React, { useState, useCallback } from 'react';
import { Send, FileText, User, Mail, Phone, MapPin } from 'lucide-react';
import FormInput from './form/FormInput';
import FormSelect from './form/FormSelect';
import FormTextarea from './form/FormTextarea';
import { RequestFormData } from '../types/form';
import { requestTypeOptions } from '../utils/constants';
import { validatePhone, validateEmail, formatPhone } from '../utils/validation';

const initialFormState: RequestFormData = {
  fullName: '',
  email: '',
  phone: '',
  address: '',
  requestType: '',
  description: '',
};

const RequestForm: React.FC = () => {
  const [formData, setFormData] = useState<RequestFormData>(initialFormState);
  const [errors, setErrors] = useState<Partial<Record<keyof RequestFormData, string>>>({});

  const validateForm = useCallback(() => {
    const newErrors: Partial<Record<keyof RequestFormData, string>> = {};

    if (!validateEmail(formData.email)) {
      newErrors.email = 'Пожалуйста, введите корректный email';
    }

    if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Введите телефон в формате +7 (999) 999-99-99';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [formData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      console.log('Form submitted:', formData);
      alert('Запрос успешно отправлен!');
      setFormData(initialFormState);
      setErrors({});
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let formattedValue = value;

    if (name === 'phone') {
      formattedValue = formatPhone(value);
    }

    setFormData(prev => ({
      ...prev,
      [name]: formattedValue,
    }));

    // Clear error when user starts typing
    if (errors[name as keyof RequestFormData]) {
      setErrors(prev => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-xl p-8 border border-gray-100">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-blue-900 mb-2">Форма обращения</h2>
          <p className="text-gray-600">Заполните форму ниже для отправки вашего запроса</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormInput
              label="ФИО"
              name="fullName"
              type="text"
              placeholder="Иванов Иван Иванович"
              value={formData.fullName}
              onChange={handleChange}
              icon={User}
              error={errors.fullName}
            />

            <FormInput
              label="Email"
              name="email"
              type="email"
              placeholder="example@mail.ru"
              value={formData.email}
              onChange={handleChange}
              icon={Mail}
              error={errors.email}
            />

            <FormInput
              label="Телефон"
              name="phone"
              type="tel"
              placeholder="+7 (999) 999-99-99"
              value={formData.phone}
              onChange={handleChange}
              icon={Phone}
              error={errors.phone}
            />

            <FormInput
              label="Адрес"
              name="address"
              type="text"
              placeholder="ул. Ленина, д. 1, кв. 1"
              value={formData.address}
              onChange={handleChange}
              icon={MapPin}
              error={errors.address}
            />
          </div>

          <FormSelect
            label="Тип обращения"
            name="requestType"
            value={formData.requestType}
            onChange={handleChange}
            icon={FileText}
            options={requestTypeOptions}
            error={errors.requestType}
          />

          <FormTextarea
            label="Описание обращения"
            name="description"
            placeholder="Подробно опишите вашу проблему или предложение..."
            value={formData.description}
            onChange={handleChange}
            icon={FileText}
            error={errors.description}
          />

          <button
            type="submit"
            className="w-full bg-blue-900 hover:bg-blue-800 text-white font-medium py-3 px-6 rounded-md transition duration-200 flex items-center justify-center gap-2 shadow-lg"
          >
            <Send size={18} />
            Отправить обращение
          </button>
        </form>
      </div>
    </div>
  );
};

export default RequestForm;