import React from 'react';
import { Mail, Phone, Clock } from 'lucide-react';
import { contactInfo, workingHours } from '../utils/constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-8 px-4">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Mail size={18} />
            Контактная информация
          </h3>
          <p className="text-sm">Email: {contactInfo.email}</p>
          <p className="text-sm">Тел: {contactInfo.phone}</p>
          <p className="text-sm">Факс: {contactInfo.fax}</p>
        </div>
        <div>
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Clock size={18} />
            Часы работы
          </h3>
          <p className="text-sm">{workingHours.weekdays}</p>
          <p className="text-sm">{workingHours.weekend}</p>
          <p className="text-sm">{workingHours.lunch}</p>
        </div>
        <div>
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Phone size={18} />
            Горячая линия
          </h3>
          <p className="text-sm">Круглосуточная поддержка</p>
          <p className="text-yellow-400 font-semibold">{contactInfo.hotline}</p>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-8 pt-8 border-t border-gray-800 text-center text-sm">
        <p>© {new Date().getFullYear()} Администрация города. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;