import React from 'react';
import { Landmark } from 'lucide-react';
import { contactInfo } from '../utils/constants';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-900 text-white py-6 px-4 shadow-lg">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Landmark size={32} className="text-yellow-400" />
          <div>
            <h1 className="text-2xl font-bold">Администрация города</h1>
            <p className="text-blue-200 text-sm">Портал электронных обращений граждан</p>
          </div>
        </div>
        <div className="text-right text-sm">
          <p className="text-blue-200">Телефон горячей линии:</p>
          <p className="text-yellow-400 font-semibold">{contactInfo.hotline}</p>
        </div>
      </div>
    </header>
  );
};

export default Header;